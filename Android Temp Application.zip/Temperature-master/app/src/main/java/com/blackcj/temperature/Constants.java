package com.blackcj.temperature;

/**
 * Created by Chris on 10/2/2014.
 */
public class Constants {
    public static final String BASE_URL = "http://blackcj.com";
}
