10/2 - 8 hrs - initial check in with core functionality
10/4 - 30 minutes - clean up
10/5 - 2 hr - report view styling and state logic
10/5 - 4 hrs - Added an overlapping scroll effect to the current temperature page.

14.5 hrs total