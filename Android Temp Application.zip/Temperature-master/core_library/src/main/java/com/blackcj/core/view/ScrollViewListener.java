package com.blackcj.core.view;

/**
 * Created by Chris on 10/5/2014.
 */
public interface ScrollViewListener {

    void onScrollChanged(ObservableScrollView scrollView, int x, int y, int oldx, int oldy);

}
